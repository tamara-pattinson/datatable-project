1.	Open a new file and save it in the datatable project folder as index.html
2.	Add the basic elements of doctype, html, head, and body to the index.html file.
3.	Add a div and h1 tag
4.	From the datatables.net website home page, 
5.	Navigate to Examples  Basic initialization  Zero configuration
6.	Halfway down the page you will find the required file references and code instructions.
7.	copy the urls for the jquery and datatable library files.
8.	In the head section of the web page paste these two links
9.	And add 2 script tags using these urls as the source attributes
10.	Navigate back to the data tables web page and select the css tab
11.	Copy the stylesheet link 
12.	Add a link tag to the web page and copy the stylesheet url to the href attribute. 
13.	From the website select the html tab and select copy in the upper right corner of the panel.
14.	Paste this in the div section of the web page.
15.	Add a new file in the js folder and naming it tableinit.js
16.	From the datatable web page select the javascript tab and copy the jquery initialize function.
17.	Paste the code in the tableinit javascript file
18.	Add a new script reference to the tabaleinit script in the index head.
19.	Save your work and open index.html in a browser
