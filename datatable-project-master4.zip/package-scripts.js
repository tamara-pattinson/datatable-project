module.exports = {
  scripts: {
      test: 'mocha test/*/*'
     }
};
