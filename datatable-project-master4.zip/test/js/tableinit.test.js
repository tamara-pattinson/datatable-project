const fs = require('fs');
const chai = require('chai');
const path = require('path');
const jsdom = require('jsdom');
const expect = chai.expect;
let html;
describe('tableinit.js test cases ', () => {

    beforeEach(() => {
        html = fs.readFileSync(path.resolve(__dirname, '../../tableinit.js'), 'utf8');
    });

    
    it("should have $('#example').DataTable(); in the document ready function','js/tableinit.js", () => {
        expect(html.includes("$('#example').DataTable();")).eql(true)
    });
})
