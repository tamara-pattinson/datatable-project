const fs = require('fs');
const chai = require('chai');
const path = require('path');
const jsdom = require('jsdom');
const expect = chai.expect;

describe('Index-final.html test cases ', () => {

    beforeEach(() => {
        const html = fs.readFileSync(path.resolve(__dirname, '../../index-final.html'), 'utf8');
        const dom = new jsdom.JSDOM(html);
        global.window = dom.window;
        global.document = dom.window.document; 
    });

    it('should have a table with an id=example', () => {
        const example = global.document.getElementById("example");
        expect(global.document.body.contains(example)).eql(true)
    });    



    it('should have a stylesheet reference for https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css', () => {
        const checkScript = isScriptLoaded('https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js');
        expect(checkScript).eql(true)

    });

    it('The html file must have 4 file references and a table with correct id and class.', () => {
        const scriptCount = global.document.querySelectorAll("script");
        const styleSheetCount = global.document.querySelectorAll("link");
 
        expect(scriptCount).length(3)
        expect(styleSheetCount).length(1)

    });
    
    function isScriptLoaded(src)
    {
        return global.document.querySelector('script[src="' + src + '"]') ? true : false;
    }
})
